# FityoraStore — Backup sebelum baseline produksi

Project sasaran: `fityorastore-production`  
Project ref: `xgmbwvwiryimwenhwhbu`  
Tanggal pemeriksaan: 30 Oktober 2026

## Mengapa ini wajib

Organisasi Supabase saat ini berada di paket Free. Dokumentasi Supabase menyatakan backup harian otomatis tersedia untuk paket Pro, Team, dan Enterprise; proyek Free dianjurkan melakukan ekspor rutin dengan Supabase CLI dan menyimpan salinan off-site.

Karena itu, arsip lama yang tidak dapat ditemukan/diverifikasi tidak cukup untuk menjadi dasar perubahan produksi.

## Jalankan dari root Codespaces

1. Buka repository `FITYORATOPUP` pada branch kerja `phase61-dual-maintenance-controls`.
2. Pastikan terminal berada di root repository.
3. Jalankan:

   ```bash
   bash scripts/production-backup-preflight.sh
   ```

4. Saat diminta, masukkan connection string database dari Supabase Dashboard → **Connect**. Input disembunyikan. Gunakan connection string untuk project ref `xgmbwvwiryimwenhwhbu` saja.
5. Skrip membuat `roles.sql`, `schema.sql`, `data.sql`, checksum, manifest, dan arsip `.tar.gz` di folder `backups/`.

Skrip berhenti bila project ref tidak cocok, Supabase CLI tidak ada, Docker tidak aktif, atau dump kosong. Jangan mengirim password/connection string ke chat dan jangan commit arsip backup ke GitHub.

## Batas cakupan dump standar

Perintah resmi `supabase db dump` menjalankan `pg_dump` dan mengecualikan schema terkelola Supabase seperti `auth`, `storage`, dan schema extension. Tiga file SQL itu **bukan** backup penuh project.

Sebelum baseline diizinkan, lengkapi dan simpan terpisah secara aman:

- **Auth:** pastikan akun Author/Admin dapat dipulihkan. Dokumentasikan Auth URL/site URL, redirect URLs, email confirmation, OAuth providers, SMTP, CAPTCHA, dan pengaturan sesi. Jangan menaruh secret provider/SMTP atau token di ZIP repository.
- **Storage:** catat bucket `payment-proofs` (private, limit 5 MB, MIME JPG/PNG/WebP), policies `storage.objects`, dan daftar/unduhan semua objek. Audit saat ini menunjukkan 0 objek, tetapi konfigurasi bucket dan policy tetap harus direkonstruksi/dibandingkan.
- **Database customizations:** pertahankan event trigger `ensure_rls`, fungsi event-trigger terkait, policy, grants, indexes, triggers, extensions, dan fungsi custom. Schema dump perlu ditinjau, tidak boleh langsung dipulihkan ke produksi.
- **Recovery proof:** restore dump ke project uji/throwaway terpisah (bukan project produksi), lalu verifikasi jumlah row, login Auth, bucket/policy, RPC, grants, RLS, event triggers, serta katalog. Arsip yang belum diuji restore bukan backup yang tervalidasi.

## Status produksi yang telah diverifikasi baca-saja

- Paket: 309; brand: 18; kategori: 3; order: 0; profile: 1.
- `auth.users`: 1; `auth.identities`: 1; sesi Auth: 4; refresh-token rows: 18.
- `storage.buckets`: 1 (`payment-proofs`, private); `storage.objects`: 0.
- RLS aktif di seluruh 11 tabel publik.
- `site_settings.maintenance_enabled` saat pemeriksaan: `true`.
- `create_topup_order(...)` belum membaca `site_settings` dan belum memeriksa maintenance.
- Riwayat `supabase_migrations.schema_migrations` tidak ada.
- Event trigger `ensure_rls` aktif dan harus dipertahankan.

Temuan ini adalah inventaris, bukan pengganti dump/restore test. Audit keamanan juga menemukan akses EXECUTE browser untuk `rls_auto_enable()`, beberapa RPC SECURITY DEFINER, kebijakan RLS permisif ganda dan tiga pasang indeks duplikat. Jangan menghapus trigger/policy/index secara massal sebelum definisi dan dependency diperiksa.

## Gerbang baseline setelah backup valid

Baru setelah backup mencakup database + Auth + Storage/config dan bukti restore tersedia:

1. Arsipkan semua 28 migrasi aktif yang lama di luar `supabase/migrations/`, tanpa menghapus salinan aslinya.
2. Cocokkan schema dump dengan read-only audit produksi.
3. Jalankan `supabase db pull --linked` di working copy yang bersih dan project link telah dicek sekali lagi.
4. Review SQL baseline yang dihasilkan dan bandingkan fungsi, grants, policies, indexes, triggers, extensions, dan Storage policies.
5. Uji pemulihan di database lokal/throwaway.
6. Verifikasi migration ledger baseline sebelum menulis migrasi forward.

## Perintah yang DILARANG saat ini

```bash
supabase db push
supabase db reset --linked
supabase migration repair --status applied
```

Jangan jalankan migrasi katalog lama, seed Phase 39/40, Phase 62, atau Phase 63 ke produksi sebelum gerbang di atas dipenuhi.
