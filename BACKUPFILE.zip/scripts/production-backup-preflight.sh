#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

EXPECTED_PROJECT_REF='xgmbwvwiryimwenhwhbu'
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${1:-backups/production-pre-baseline-${STAMP}}"
ARCHIVE="${OUT_DIR%/}.tar.gz"

fail() { printf 'GAGAL: %s\n' "$*" >&2; exit 1; }

[[ -f package.json && -d supabase/migrations ]] || fail 'Jalankan skrip dari root repository FITYORATOPUP.'
command -v supabase >/dev/null 2>&1 || fail 'Supabase CLI belum tersedia. Gunakan `npx supabase` atau pasang CLI terlebih dahulu.'
command -v docker >/dev/null 2>&1 || fail 'Docker CLI tidak ditemukan; db dump resmi Supabase memerlukan runtime Docker.'
docker info >/dev/null 2>&1 || fail 'Docker daemon tidak aktif/terjangkau di Codespaces. Nyalakan Docker atau jalankan dari mesin yang memiliki Docker.'

DB_URL="${SUPABASE_DB_URL:-}"
if [[ -z "$DB_URL" ]]; then
  printf 'Masukkan connection string database Supabase (input disembunyikan): '
  IFS= read -r -s DB_URL
  printf '\n'
fi
[[ "$DB_URL" == postgresql://* || "$DB_URL" == postgres://* ]] || fail 'Connection string harus diawali postgresql:// atau postgres://.'
[[ "$DB_URL" == *"${EXPECTED_PROJECT_REF}"* ]] || fail "Connection string tidak mengandung project ref ${EXPECTED_PROJECT_REF}; dibatalkan agar tidak salah project."

mkdir -p "$OUT_DIR"
chmod 700 "$OUT_DIR"

cleanup() { unset DB_URL SUPABASE_DB_URL 2>/dev/null || true; }
trap cleanup EXIT

printf 'Membuat dump roles.sql...\n'
supabase db dump --db-url "$DB_URL" -f "$OUT_DIR/roles.sql" --role-only
printf 'Membuat dump schema.sql...\n'
supabase db dump --db-url "$DB_URL" -f "$OUT_DIR/schema.sql"
printf 'Membuat dump data.sql...\n'
supabase db dump --db-url "$DB_URL" -f "$OUT_DIR/data.sql" --use-copy --data-only -x 'storage.buckets_vectors' -x 'storage.vector_indexes'

for file in roles.sql schema.sql data.sql; do
  [[ -s "$OUT_DIR/$file" ]] || fail "Dump $file kosong atau tidak terbentuk."
done

CLI_VERSION="$(supabase --version 2>&1 | head -n 1 || true)"
GIT_BRANCH="$(git branch --show-current 2>/dev/null || printf 'unknown')"
GIT_COMMIT="$(git rev-parse HEAD 2>/dev/null || printf 'unknown')"
cat > "$OUT_DIR/MANIFEST.txt" <<EOF
FITYORATOPUP production pre-baseline logical database dump
UTC created: ${STAMP}
Expected project ref: ${EXPECTED_PROJECT_REF}
Supabase CLI: ${CLI_VERSION}
Git branch: ${GIT_BRANCH}
Git commit: ${GIT_COMMIT}
Included files: roles.sql, schema.sql, data.sql

IMPORTANT: This is a logical SQL dump, NOT a full Supabase project backup.
The standard Supabase db dump excludes managed schemas including auth and storage,
and extension-managed schemas. It does not download Storage object files or export
Auth provider/SMTP/project settings. Those items must be captured separately.
Do not treat this archive as restore-tested until it has been restored to a separate
throwaway project and checked.
EOF

if command -v sha256sum >/dev/null 2>&1; then
  (cd "$OUT_DIR" && sha256sum roles.sql schema.sql data.sql MANIFEST.txt > SHA256SUMS.txt)
elif command -v shasum >/dev/null 2>&1; then
  (cd "$OUT_DIR" && shasum -a 256 roles.sql schema.sql data.sql MANIFEST.txt > SHA256SUMS.txt)
else
  fail 'sha256sum/shasum tidak tersedia untuk membuat checksum.'
fi

mkdir -p "$(dirname "$ARCHIVE")"
tar -czf "$ARCHIVE" -C "$(dirname "$OUT_DIR")" "$(basename "$OUT_DIR")"
[[ -s "$ARCHIVE" ]] || fail 'Arsip tar.gz gagal dibuat.'

printf '\nBERHASIL membuat logical dump (belum full backup):\n  Folder: %s\n  Arsip:  %s\n\n' "$OUT_DIR" "$ARCHIVE"
printf 'JANGAN commit/upload backup ini ke GitHub. Simpan di lokasi privat/off-site.\n'
printf 'Lihat BACKUP_SCOPE_AND_NEXT_STEPS.md untuk komponen Auth/Storage/config yang masih perlu diamankan.\n'
