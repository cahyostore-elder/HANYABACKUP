FITYORATOPUP — Production Backup Preflight

Read BACKUP_SCOPE_AND_NEXT_STEPS.md first.
Run from the FITYORATOPUP repository root:
  bash scripts/production-backup-preflight.sh

This helper creates a logical database dump only. It does not claim to back up Auth,
Storage object files, Auth provider settings, or other project-level configuration.
It does not apply migrations or change production.
