-- Phase 65 backup-scope inventory. READ ONLY; run on intended production project.
SELECT 'auth.users' AS object_name, count(*) AS row_count FROM auth.users
UNION ALL SELECT 'auth.identities', count(*) FROM auth.identities
UNION ALL SELECT 'auth.sessions', count(*) FROM auth.sessions
UNION ALL SELECT 'auth.refresh_tokens', count(*) FROM auth.refresh_tokens
UNION ALL SELECT 'storage.buckets', count(*) FROM storage.buckets
UNION ALL SELECT 'storage.objects', count(*) FROM storage.objects
UNION ALL SELECT 'public.profiles', count(*) FROM public.profiles
UNION ALL SELECT 'public.topup_categories', count(*) FROM public.topup_categories
UNION ALL SELECT 'public.brands', count(*) FROM public.brands
UNION ALL SELECT 'public.packages', count(*) FROM public.packages
UNION ALL SELECT 'public.orders', count(*) FROM public.orders
UNION ALL SELECT 'public.site_settings', count(*) FROM public.site_settings
ORDER BY object_name;

-- Storage bucket policy/config inventory (no file contents or secrets).
SELECT id, name, public, file_size_limit, allowed_mime_types
FROM storage.buckets
ORDER BY name;

SELECT tablename, policyname, roles, cmd, qual, with_check
FROM pg_policies
WHERE schemaname = 'storage'
ORDER BY tablename, policyname;

-- Important event triggers; do not drop ensure_rls.
SELECT e.evtname, e.evtenabled, e.evtevent, e.evttags, p.proname AS function_name
FROM pg_event_trigger AS e
JOIN pg_proc AS p ON p.oid = e.evtfoid
ORDER BY e.evtname;
