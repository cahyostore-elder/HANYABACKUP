# Phase 57 — RPC Aman untuk Harga Modal Supplier

## Apa yang berubah

- Dashboard membaca `package_supplier_costs` melalui `admin_list_package_supplier_costs()`, bukan akses SELECT langsung dari browser.
- Tombol **Simpan Modal Saja — Harga Jual Tetap** menggunakan `admin_upsert_package_supplier_cost()` dan tidak mengirim/menulis harga jual.
- Harga modal yang belum dimasukkan dibiarkan kosong; tidak dianggap Rp0 dan tidak diisi dari harga jual.
- Kolom `updated_by` mencatat pengguna admin yang menyimpan harga modal, termasuk jalur simpan paket dan impor harga massal.
- Hak akses langsung `anon` dan `authenticated` ke tabel harga modal dicabut. RPC memeriksa autentikasi dan `public.is_admin()` di database.
- Bulk pricing tetap menampilkan pratinjau dan membutuhkan konfirmasi eksplisit; fitur itu tetap mengubah harga jual hanya setelah dikonfirmasi.

## Pemasangan

1. Buat cadangan database Supabase.
2. Buka project Supabase yang dipakai website, lalu **SQL Editor → New query**.
3. Jalankan isi `supabase/migrations/20261028050000_phase57_supplier_cost_rpc_security.sql`.
4. Pastikan query sukses. Migration ini menambah kolom audit bila belum ada, mengganti definisi RPC terkait, dan menyegarkan cache skema PostgREST. Tidak ada harga katalog/modal yang diubah oleh migration tersebut.
5. Build dan audit paket dari root project: `npm ci`, `npm run audit:phase57`, `npm run audit:phase52`, `npm run audit:phase56`, lalu `npm run check`.
6. Deploy frontend setelah migration berhasil. Di Admin → Kelola Produk, edit paket yang ada lalu gunakan **Simpan Modal Saja — Harga Jual Tetap**.
7. Verifikasi harga jual paket tersebut tidak berubah; harga modal muncul saat halaman dimuat ulang. Coba akun non-admin untuk memastikan pemanggilan RPC ditolak.

## Catatan

- Fungsi admin membutuhkan sesi Supabase yang valid dan role `admin` atau `author` di `public.profiles`.
- Jangan menaruh `service_role` key di frontend. UI menggunakan public/publishable key dan authorization ditegakkan oleh RPC/RLS.
- Harga modal harus dimasukkan dari data supplier aktual. Jangan memakai harga jual sekarang sebagai estimasi modal.
