import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const admin = readFileSync(new URL('../src/pages/AdminPage.tsx', import.meta.url), 'utf8');
const migration = readFileSync(new URL('../supabase/migrations/20261028050000_phase57_supplier_cost_rpc_security.sql', import.meta.url), 'utf8');
const packageJson = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('admin cost data loads through the admin-gated RPC, not direct table reads', () => {
  assert.match(admin, /supabase\.rpc\('admin_list_package_supplier_costs'\)/);
  assert.doesNotMatch(admin, /supabase\.from\('package_supplier_costs'\)/);
});

test('supplier-only button uses dedicated RPC and never submits a selling price', () => {
  const start = admin.indexOf('const saveSupplierCostOnly = async () =>');
  const end = admin.indexOf('const remove = async (id: string)', start);
  assert.ok(start >= 0 && end > start, 'supplier-only save handler exists');
  const handler = admin.slice(start, end);
  assert.match(handler, /supabase\.rpc\('admin_upsert_package_supplier_cost'/);
  assert.match(handler, /p_package_id: editing\.id/);
  assert.match(handler, /p_supplier_cost: supplierCost/);
  assert.doesNotMatch(handler, /p_price|admin_save_package|admin_update_package_pricing/);
  assert.match(admin, /Simpan Modal Saja — Harga Jual Tetap/);
});

test('unknown supplier costs remain blank and are never silently initialized to zero', () => {
  assert.match(admin, /supplier_cost: supplierCosts\[p\.id\] == null \? '' : supplierCosts\[p\.id\]/);
  assert.match(admin, /value=\{String\(editing\.supplier_cost \?\? ''\)\}/);
  assert.match(admin, /Modal \{supplierCosts\[p\.id\] == null \? 'belum diisi'/);
  assert.match(admin, /const supplierCost = parseRupiah\(String\(editing\.supplier_cost \?\? ''\)\.trim\(\)\)/);
  assert.match(admin, /Belum diisi/);
});

test('supplier-cost table is inaccessible directly to browser roles and RPCs are admin-gated', () => {
  assert.match(migration, /ADD COLUMN IF NOT EXISTS updated_by uuid REFERENCES auth\.users\(id\)/);
  assert.match(migration, /REVOKE ALL ON TABLE public\.package_supplier_costs FROM PUBLIC, anon, authenticated/);
  assert.match(migration, /GRANT ALL ON TABLE public\.package_supplier_costs TO service_role/);
  assert.match(migration, /CREATE OR REPLACE FUNCTION public\.admin_list_package_supplier_costs/);
  assert.match(migration, /CREATE OR REPLACE FUNCTION public\.admin_upsert_package_supplier_cost/);
  assert.match(migration, /auth\.uid\(\) IS NULL OR NOT public\.is_admin\(\)/);
  assert.match(migration, /updated_by = auth\.uid\(\)/);
  assert.match(migration, /REVOKE ALL ON FUNCTION public\.admin_upsert_package_supplier_cost\(uuid, numeric\) FROM PUBLIC, anon/);
  assert.match(migration, /GRANT EXECUTE ON FUNCTION public\.admin_upsert_package_supplier_cost\(uuid, numeric\) TO authenticated/);
});

test('Phase 57 audit is available and included in release audit', () => {
  assert.equal(packageJson.scripts['audit:phase57'], 'node --test scripts/phase57-supplier-cost-rpc.test.mjs');
  assert.match(packageJson.scripts['audit:release'], /audit:phase57/);
});
